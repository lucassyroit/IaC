-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 192.168.1.28    Database: phpbb
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `phpbb_users`
--

DROP TABLE IF EXISTS `phpbb_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phpbb_users` (
  `user_id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_type` tinyint NOT NULL DEFAULT '0',
  `group_id` mediumint unsigned NOT NULL DEFAULT '3',
  `user_permissions` mediumtext COLLATE utf8mb3_bin NOT NULL,
  `user_perm_from` mediumint unsigned NOT NULL DEFAULT '0',
  `user_ip` varchar(40) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_regdate` int unsigned NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `username_clean` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_password` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_passchg` int unsigned NOT NULL DEFAULT '0',
  `user_email` varchar(100) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_birthday` varchar(10) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_lastvisit` int unsigned NOT NULL DEFAULT '0',
  `user_lastmark` int unsigned NOT NULL DEFAULT '0',
  `user_lastpost_time` int unsigned NOT NULL DEFAULT '0',
  `user_lastpage` varchar(200) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_last_confirm_key` varchar(10) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_last_search` int unsigned NOT NULL DEFAULT '0',
  `user_warnings` tinyint NOT NULL DEFAULT '0',
  `user_last_warning` int unsigned NOT NULL DEFAULT '0',
  `user_login_attempts` tinyint NOT NULL DEFAULT '0',
  `user_inactive_reason` tinyint NOT NULL DEFAULT '0',
  `user_inactive_time` int unsigned NOT NULL DEFAULT '0',
  `user_posts` mediumint unsigned NOT NULL DEFAULT '0',
  `user_lang` varchar(30) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_timezone` varchar(100) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_dateformat` varchar(64) COLLATE utf8mb3_bin NOT NULL DEFAULT 'd M Y H:i',
  `user_style` mediumint unsigned NOT NULL DEFAULT '0',
  `user_rank` mediumint unsigned NOT NULL DEFAULT '0',
  `user_colour` varchar(6) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_new_privmsg` int NOT NULL DEFAULT '0',
  `user_unread_privmsg` int NOT NULL DEFAULT '0',
  `user_last_privmsg` int unsigned NOT NULL DEFAULT '0',
  `user_message_rules` tinyint unsigned NOT NULL DEFAULT '0',
  `user_full_folder` int NOT NULL DEFAULT '-3',
  `user_emailtime` int unsigned NOT NULL DEFAULT '0',
  `user_topic_show_days` smallint unsigned NOT NULL DEFAULT '0',
  `user_topic_sortby_type` varchar(1) COLLATE utf8mb3_bin NOT NULL DEFAULT 't',
  `user_topic_sortby_dir` varchar(1) COLLATE utf8mb3_bin NOT NULL DEFAULT 'd',
  `user_post_show_days` smallint unsigned NOT NULL DEFAULT '0',
  `user_post_sortby_type` varchar(1) COLLATE utf8mb3_bin NOT NULL DEFAULT 't',
  `user_post_sortby_dir` varchar(1) COLLATE utf8mb3_bin NOT NULL DEFAULT 'a',
  `user_notify` tinyint unsigned NOT NULL DEFAULT '0',
  `user_notify_pm` tinyint unsigned NOT NULL DEFAULT '1',
  `user_notify_type` tinyint NOT NULL DEFAULT '0',
  `user_allow_pm` tinyint unsigned NOT NULL DEFAULT '1',
  `user_allow_viewonline` tinyint unsigned NOT NULL DEFAULT '1',
  `user_allow_viewemail` tinyint unsigned NOT NULL DEFAULT '1',
  `user_allow_massemail` tinyint unsigned NOT NULL DEFAULT '1',
  `user_options` int unsigned NOT NULL DEFAULT '230271',
  `user_avatar` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_avatar_type` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_avatar_width` smallint unsigned NOT NULL DEFAULT '0',
  `user_avatar_height` smallint unsigned NOT NULL DEFAULT '0',
  `user_sig` mediumtext COLLATE utf8mb3_bin NOT NULL,
  `user_sig_bbcode_uid` varchar(8) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_sig_bbcode_bitfield` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_jabber` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_actkey` varchar(32) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `reset_token` varchar(64) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `reset_token_expiration` int unsigned NOT NULL DEFAULT '0',
  `user_newpasswd` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_form_salt` varchar(32) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_new` tinyint unsigned NOT NULL DEFAULT '1',
  `user_reminded` tinyint NOT NULL DEFAULT '0',
  `user_reminded_time` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username_clean` (`username_clean`),
  KEY `user_birthday` (`user_birthday`),
  KEY `user_type` (`user_type`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_users`
--

LOCK TABLES `phpbb_users` WRITE;
/*!40000 ALTER TABLE `phpbb_users` DISABLE KEYS */;
INSERT INTO `phpbb_users` VALUES (1,2,1,'00000000000g13ydmo\nhwby9w000000\nhwby9w000000',0,'',1702136592,'Anonymous','anonymous','',0,'','',0,0,0,'','',0,0,0,0,0,0,0,'en','','d M Y H:i',1,0,'',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,1,1,1,0,230271,'','',0,0,'','','','','','',0,'','la56duh07v6po5lq',1,0,0),(2,3,5,'zik0zjzik0zjzik0zi\nhwby9w000000\nzik0zjzih7uo',0,'192.168.1.24',1702136592,'admin','admin','$argon2id$v=19$m=65536,t=4,p=2$b0Y3OWFETk5GcGw3YlA5Uw$4upr0RQWm/EmMPVfjtHYkJK+gROj+aC5Cv2daL1Tja0',0,'joppevandenbroeck@live.be','',1702136772,0,0,'','',0,0,0,0,0,0,1,'en','','D M d, Y g:i a',1,1,'AA0000',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,1,1,1,1,230271,'','',0,0,'','','','','','',0,'','a71fbpsgu4zdavxn',1,0,0),(3,2,6,'',0,'',1702136592,'AdsBot [Google]','adsbot [google]','',1702136592,'','',0,1702136592,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','8oqy8qplb50jj0c2',0,0,0),(4,2,6,'',0,'',1702136592,'Ahrefs [Bot]','ahrefs [bot]','',1702136592,'','',0,1702136592,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','ill3q8vx0l2bnaj2',0,0,0),(5,2,6,'',0,'',1702136592,'Alexa [Bot]','alexa [bot]','',1702136592,'','',0,1702136592,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','ug55rvxluu99upi4',0,0,0),(6,2,6,'',0,'',1702136592,'Alta Vista [Bot]','alta vista [bot]','',1702136592,'','',0,1702136592,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','apshdq7b992oihgg',0,0,0),(7,2,6,'',0,'',1702136592,'Amazon [Bot]','amazon [bot]','',1702136592,'','',0,1702136592,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','pecdo89k1knjur6e',0,0,0),(8,2,6,'',0,'',1702136592,'Ask Jeeves [Bot]','ask jeeves [bot]','',1702136592,'','',0,1702136592,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','s76jc91vl7v35qez',0,0,0),(9,2,6,'',0,'',1702136592,'Baidu [Spider]','baidu [spider]','',1702136592,'','',0,1702136592,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','3p6fp2urf3arsp6s',0,0,0),(10,2,6,'',0,'',1702136592,'Bing [Bot]','bing [bot]','',1702136592,'','',0,1702136592,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','3yzu1ok65k6q11kf',0,0,0),(11,2,6,'',0,'',1702136592,'DuckDuckGo [Bot]','duckduckgo [bot]','',1702136592,'','',0,1702136592,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','lbq1zglqb12qvy0x',0,0,0),(12,2,6,'',0,'',1702136593,'Exabot [Bot]','exabot [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','5z1gao70xsyldvk5',0,0,0),(13,2,6,'',0,'',1702136593,'FAST Enterprise [Crawler]','fast enterprise [crawler]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','ndxebg4ulcytrqx8',0,0,0),(14,2,6,'',0,'',1702136593,'FAST WebCrawler [Crawler]','fast webcrawler [crawler]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','4y3sn3qievmygg31',0,0,0),(15,2,6,'',0,'',1702136593,'Francis [Bot]','francis [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','lg88lnanuad7fb82',0,0,0),(16,2,6,'',0,'',1702136593,'Gigabot [Bot]','gigabot [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','0s90engaveuz9y2d',0,0,0),(17,2,6,'',0,'',1702136593,'Google Adsense [Bot]','google adsense [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','gv0qju59b6gy97fu',0,0,0),(18,2,6,'',0,'',1702136593,'Google Desktop','google desktop','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','9t37ddek9fqggfps',0,0,0),(19,2,6,'',0,'',1702136593,'Google Feedfetcher','google feedfetcher','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','lvxrgraz23b6ncll',0,0,0),(20,2,6,'',0,'',1702136593,'Google [Bot]','google [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','opeahiyrjpk0xbro',0,0,0),(21,2,6,'',0,'',1702136593,'Heise IT-Markt [Crawler]','heise it-markt [crawler]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','2kn54vvedqclpvly',0,0,0),(22,2,6,'',0,'',1702136593,'Heritrix [Crawler]','heritrix [crawler]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','s05nhdr3hy70eiz8',0,0,0),(23,2,6,'',0,'',1702136593,'IBM Research [Bot]','ibm research [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','g6l27ek1njx8waaa',0,0,0),(24,2,6,'',0,'',1702136593,'ICCrawler - ICjobs','iccrawler - icjobs','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','3d184nr3t7rw1qv5',0,0,0),(25,2,6,'',0,'',1702136593,'ichiro [Crawler]','ichiro [crawler]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','fcti0vb02k0v68ta',0,0,0),(26,2,6,'',0,'',1702136593,'Majestic-12 [Bot]','majestic-12 [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','p0vyof7dv0gjd2b7',0,0,0),(27,2,6,'',0,'',1702136593,'Metager [Bot]','metager [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','1gdad983x47rd0gu',0,0,0),(28,2,6,'',0,'',1702136593,'MSN NewsBlogs','msn newsblogs','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','qkcauzctgzu8rd8f',0,0,0),(29,2,6,'',0,'',1702136593,'MSN [Bot]','msn [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','su95xjl4g78v6txu',0,0,0),(30,2,6,'',0,'',1702136593,'MSNbot Media','msnbot media','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','pb182tdvvg4p11rd',0,0,0),(31,2,6,'',0,'',1702136593,'NG-Search [Bot]','ng-search [bot]','',1702136593,'','',0,1702136593,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','su2i4h4tayyvuoeh',0,0,0),(32,2,6,'',0,'',1702136594,'Nutch [Bot]','nutch [bot]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','qlk8efk9q1hhcio1',0,0,0),(33,2,6,'',0,'',1702136594,'Nutch/CVS [Bot]','nutch/cvs [bot]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','4r3pxnq4opm5itcc',0,0,0),(34,2,6,'',0,'',1702136594,'OmniExplorer [Bot]','omniexplorer [bot]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','jzvfpmmpg65pgxsc',0,0,0),(35,2,6,'',0,'',1702136594,'Online link [Validator]','online link [validator]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','b95esdq4djdg9sye',0,0,0),(36,2,6,'',0,'',1702136594,'psbot [Picsearch]','psbot [picsearch]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','gnqicakog8ynngek',0,0,0),(37,2,6,'',0,'',1702136594,'Seekport [Bot]','seekport [bot]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','egjh7o3ykod4furp',0,0,0),(38,2,6,'',0,'',1702136594,'Semrush [Bot]','semrush [bot]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','0hlw9vs9t0siypan',0,0,0),(39,2,6,'',0,'',1702136594,'Sensis [Crawler]','sensis [crawler]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','twk6fcosqirzy5iv',0,0,0),(40,2,6,'',0,'',1702136594,'SEO Crawler','seo crawler','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','ob3b76qadz5q2v34',0,0,0),(41,2,6,'',0,'',1702136594,'Seoma [Crawler]','seoma [crawler]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','04dvr7vwygfnj0vs',0,0,0),(42,2,6,'',0,'',1702136594,'SEOSearch [Crawler]','seosearch [crawler]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','lbuh6762ullmbpax',0,0,0),(43,2,6,'',0,'',1702136594,'Snappy [Bot]','snappy [bot]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','498zpik4khiu9sto',0,0,0),(44,2,6,'',0,'',1702136594,'Steeler [Crawler]','steeler [crawler]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','hct2pfbcxxaiw387',0,0,0),(45,2,6,'',0,'',1702136594,'Synoo [Bot]','synoo [bot]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','p2qhlixukf9k61sj',0,0,0),(46,2,6,'',0,'',1702136594,'Telekom [Bot]','telekom [bot]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','wvtoh4udwao5obrs',0,0,0),(47,2,6,'',0,'',1702136594,'TurnitinBot [Bot]','turnitinbot [bot]','',1702136594,'','',0,1702136594,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','cu0hyzg94rut5hcg',0,0,0),(48,2,6,'',0,'',1702136595,'Voyager [Bot]','voyager [bot]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','n9618wtrac9k47vk',0,0,0),(49,2,6,'',0,'',1702136595,'W3 [Sitesearch]','w3 [sitesearch]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','vg7sgmbmgaa9xl26',0,0,0),(50,2,6,'',0,'',1702136595,'W3C [Linkcheck]','w3c [linkcheck]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','uxqmk3q279u2kvxs',0,0,0),(51,2,6,'',0,'',1702136595,'W3C [Validator]','w3c [validator]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','0k0ip2ncljv5qds0',0,0,0),(52,2,6,'',0,'',1702136595,'WiseNut [Bot]','wisenut [bot]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','yru743fen9z644wz',0,0,0),(53,2,6,'',0,'',1702136595,'YaCy [Bot]','yacy [bot]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','x7dz5be90nbph2px',0,0,0),(54,2,6,'',0,'',1702136595,'Yahoo MMCrawler [Bot]','yahoo mmcrawler [bot]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','774wxivjz5xahge5',0,0,0),(55,2,6,'',0,'',1702136595,'Yahoo Slurp [Bot]','yahoo slurp [bot]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','aaf7czvtpowv6m3k',0,0,0),(56,2,6,'',0,'',1702136595,'Yahoo [Bot]','yahoo [bot]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','c60xrjex0esuea7b',0,0,0),(57,2,6,'',0,'',1702136595,'YahooSeeker [Bot]','yahooseeker [bot]','',1702136595,'','',0,1702136595,0,'','',0,0,0,0,0,0,0,'en','UTC','D M d, Y g:i a',1,0,'9E8DA7',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,0,1,1,0,230271,'','',0,0,'','','','','','',0,'','o9xoz9q3zzngkcis',0,0,0),(58,0,2,'00000000000v6ez2zu\nhwby9w000000\nm6awadqmx0qo',0,'192.168.1.24',1702136842,'Joppe Van den Broeck','joppe van den broeck','$argon2id$v=19$m=65536,t=4,p=2$Ymo1LzRieUZJVDJvdlhNUg$D90XWCUXeny5lrZttmhZZ/cDH+kalnRdwZ8CvgxLsLA',1702136842,'joppevandenbroeck@outlook.com','',0,1702136842,0,'','',0,0,0,0,0,0,0,'en','Europe/Brussels','D M d, Y g:i a',1,0,'',0,0,0,0,-3,0,0,'t','d',0,'t','a',0,1,0,1,1,1,1,230271,'','',0,0,'','','','','','',0,'','jf6932yl8wjg6ua5',1,0,0);
/*!40000 ALTER TABLE `phpbb_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-09 16:49:04
