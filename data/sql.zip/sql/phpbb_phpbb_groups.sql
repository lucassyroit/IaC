-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 192.168.1.28    Database: phpbb
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `phpbb_groups`
--

DROP TABLE IF EXISTS `phpbb_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phpbb_groups` (
  `group_id` mediumint unsigned NOT NULL AUTO_INCREMENT,
  `group_type` tinyint NOT NULL DEFAULT '1',
  `group_founder_manage` tinyint unsigned NOT NULL DEFAULT '0',
  `group_skip_auth` tinyint unsigned NOT NULL DEFAULT '0',
  `group_name` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `group_desc` text COLLATE utf8mb3_bin NOT NULL,
  `group_desc_bitfield` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `group_desc_options` int unsigned NOT NULL DEFAULT '7',
  `group_desc_uid` varchar(8) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `group_display` tinyint unsigned NOT NULL DEFAULT '0',
  `group_avatar` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `group_avatar_type` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `group_avatar_width` smallint unsigned NOT NULL DEFAULT '0',
  `group_avatar_height` smallint unsigned NOT NULL DEFAULT '0',
  `group_rank` mediumint unsigned NOT NULL DEFAULT '0',
  `group_colour` varchar(6) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `group_sig_chars` mediumint unsigned NOT NULL DEFAULT '0',
  `group_receive_pm` tinyint unsigned NOT NULL DEFAULT '0',
  `group_message_limit` mediumint unsigned NOT NULL DEFAULT '0',
  `group_legend` mediumint unsigned NOT NULL DEFAULT '0',
  `group_max_recipients` mediumint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`),
  KEY `group_legend_name` (`group_legend`,`group_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_groups`
--

LOCK TABLES `phpbb_groups` WRITE;
/*!40000 ALTER TABLE `phpbb_groups` DISABLE KEYS */;
INSERT INTO `phpbb_groups` VALUES (1,3,0,0,'GUESTS','','',7,'',0,'','',0,0,0,'',0,0,0,0,5),(2,3,0,0,'REGISTERED','','',7,'',0,'','',0,0,0,'',0,0,0,0,5),(3,3,0,0,'REGISTERED_COPPA','','',7,'',0,'','',0,0,0,'',0,0,0,0,5),(4,3,0,0,'GLOBAL_MODERATORS','','',7,'',0,'','',0,0,0,'00AA00',0,0,0,2,0),(5,3,1,0,'ADMINISTRATORS','','',7,'',0,'','',0,0,0,'AA0000',0,0,0,1,0),(6,3,0,0,'BOTS','','',7,'',0,'','',0,0,0,'9E8DA7',0,0,0,0,5),(7,3,0,0,'NEWLY_REGISTERED','','',7,'',0,'','',0,0,0,'',0,0,0,0,5);
/*!40000 ALTER TABLE `phpbb_groups` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-09 16:49:00
