-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 192.168.1.28    Database: phpbb
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `phpbb_bots`
--

DROP TABLE IF EXISTS `phpbb_bots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phpbb_bots` (
  `bot_id` int unsigned NOT NULL AUTO_INCREMENT,
  `bot_active` tinyint unsigned NOT NULL DEFAULT '1',
  `bot_name` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `user_id` int unsigned NOT NULL DEFAULT '0',
  `bot_agent` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `bot_ip` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`bot_id`),
  KEY `bot_active` (`bot_active`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_bots`
--

LOCK TABLES `phpbb_bots` WRITE;
/*!40000 ALTER TABLE `phpbb_bots` DISABLE KEYS */;
INSERT INTO `phpbb_bots` VALUES (1,1,'AdsBot [Google]',3,'AdsBot-Google',''),(2,1,'Ahrefs [Bot]',4,'AhrefsBot/',''),(3,1,'Alexa [Bot]',5,'ia_archiver',''),(4,1,'Alta Vista [Bot]',6,'Scooter/',''),(5,1,'Amazon [Bot]',7,'Amazonbot/',''),(6,1,'Ask Jeeves [Bot]',8,'Ask Jeeves',''),(7,1,'Baidu [Spider]',9,'Baiduspider',''),(8,1,'Bing [Bot]',10,'bingbot/',''),(9,1,'DuckDuckGo [Bot]',11,'DuckDuckBot/',''),(10,1,'Exabot [Bot]',12,'Exabot/',''),(11,1,'FAST Enterprise [Crawler]',13,'FAST Enterprise Crawler',''),(12,1,'FAST WebCrawler [Crawler]',14,'FAST-WebCrawler/',''),(13,1,'Francis [Bot]',15,'http://www.neomo.de/',''),(14,1,'Gigabot [Bot]',16,'Gigabot/',''),(15,1,'Google Adsense [Bot]',17,'Mediapartners-Google',''),(16,1,'Google Desktop',18,'Google Desktop',''),(17,1,'Google Feedfetcher',19,'Feedfetcher-Google',''),(18,1,'Google [Bot]',20,'Googlebot',''),(19,1,'Heise IT-Markt [Crawler]',21,'heise-IT-Markt-Crawler',''),(20,1,'Heritrix [Crawler]',22,'heritrix/1.',''),(21,1,'IBM Research [Bot]',23,'ibm.com/cs/crawler',''),(22,1,'ICCrawler - ICjobs',24,'ICCrawler - ICjobs',''),(23,1,'ichiro [Crawler]',25,'ichiro/',''),(24,1,'Majestic-12 [Bot]',26,'MJ12bot/',''),(25,1,'Metager [Bot]',27,'MetagerBot/',''),(26,1,'MSN NewsBlogs',28,'msnbot-NewsBlogs/',''),(27,1,'MSN [Bot]',29,'msnbot/',''),(28,1,'MSNbot Media',30,'msnbot-media/',''),(29,1,'NG-Search [Bot]',31,'NG-Search/',''),(30,1,'Nutch [Bot]',32,'http://lucene.apache.org/nutch/',''),(31,1,'Nutch/CVS [Bot]',33,'NutchCVS/',''),(32,1,'OmniExplorer [Bot]',34,'OmniExplorer_Bot/',''),(33,1,'Online link [Validator]',35,'online link validator',''),(34,1,'psbot [Picsearch]',36,'psbot/0',''),(35,1,'Seekport [Bot]',37,'Seekbot/',''),(36,1,'Semrush [Bot]',38,'SemrushBot/',''),(37,1,'Sensis [Crawler]',39,'Sensis Web Crawler',''),(38,1,'SEO Crawler',40,'SEO search Crawler/',''),(39,1,'Seoma [Crawler]',41,'Seoma [SEO Crawler]',''),(40,1,'SEOSearch [Crawler]',42,'SEOsearch/',''),(41,1,'Snappy [Bot]',43,'Snappy/1.1 ( http://www.urltrends.com/ )',''),(42,1,'Steeler [Crawler]',44,'http://www.tkl.iis.u-tokyo.ac.jp/~crawler/',''),(43,1,'Synoo [Bot]',45,'SynooBot/',''),(44,1,'Telekom [Bot]',46,'crawleradmin.t-info@telekom.de',''),(45,1,'TurnitinBot [Bot]',47,'TurnitinBot/',''),(46,1,'Voyager [Bot]',48,'voyager/',''),(47,1,'W3 [Sitesearch]',49,'W3 SiteSearch Crawler',''),(48,1,'W3C [Linkcheck]',50,'W3C-checklink/',''),(49,1,'W3C [Validator]',51,'W3C_*Validator',''),(50,1,'WiseNut [Bot]',52,'http://www.WISEnutbot.com',''),(51,1,'YaCy [Bot]',53,'yacybot',''),(52,1,'Yahoo MMCrawler [Bot]',54,'Yahoo-MMCrawler/',''),(53,1,'Yahoo Slurp [Bot]',55,'Yahoo! DE Slurp',''),(54,1,'Yahoo [Bot]',56,'Yahoo! Slurp',''),(55,1,'YahooSeeker [Bot]',57,'YahooSeeker/','');
/*!40000 ALTER TABLE `phpbb_bots` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-09 16:49:04
