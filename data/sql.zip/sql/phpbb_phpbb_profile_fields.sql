-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: 192.168.1.28    Database: phpbb
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `phpbb_profile_fields`
--

DROP TABLE IF EXISTS `phpbb_profile_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phpbb_profile_fields` (
  `field_id` mediumint unsigned NOT NULL AUTO_INCREMENT,
  `field_name` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_type` varchar(100) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_ident` varchar(20) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_length` varchar(20) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_minlen` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_maxlen` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_novalue` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_default_value` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_validation` varchar(128) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_required` tinyint unsigned NOT NULL DEFAULT '0',
  `field_show_on_reg` tinyint unsigned NOT NULL DEFAULT '0',
  `field_hide` tinyint unsigned NOT NULL DEFAULT '0',
  `field_no_view` tinyint unsigned NOT NULL DEFAULT '0',
  `field_active` tinyint unsigned NOT NULL DEFAULT '0',
  `field_order` mediumint unsigned NOT NULL DEFAULT '0',
  `field_show_profile` tinyint unsigned NOT NULL DEFAULT '0',
  `field_show_on_vt` tinyint unsigned NOT NULL DEFAULT '0',
  `field_show_novalue` tinyint unsigned NOT NULL DEFAULT '0',
  `field_show_on_pm` tinyint unsigned NOT NULL DEFAULT '0',
  `field_show_on_ml` tinyint unsigned NOT NULL DEFAULT '0',
  `field_is_contact` tinyint unsigned NOT NULL DEFAULT '0',
  `field_contact_desc` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  `field_contact_url` varchar(255) COLLATE utf8mb3_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`field_id`),
  KEY `fld_type` (`field_type`),
  KEY `fld_ordr` (`field_order`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phpbb_profile_fields`
--

LOCK TABLES `phpbb_profile_fields` WRITE;
/*!40000 ALTER TABLE `phpbb_profile_fields` DISABLE KEYS */;
INSERT INTO `phpbb_profile_fields` VALUES (1,'phpbb_location','profilefields.type.string','phpbb_location','20','2','100','','','.*',0,0,0,0,1,1,1,1,0,1,1,0,'',''),(2,'phpbb_website','profilefields.type.url','phpbb_website','40','12','255','','','',0,0,0,0,1,2,1,1,0,1,1,1,'VISIT_WEBSITE','%s'),(3,'phpbb_interests','profilefields.type.text','phpbb_interests','3|30','2','500','','','.*',0,0,0,0,0,3,1,0,0,0,0,0,'',''),(4,'phpbb_occupation','profilefields.type.text','phpbb_occupation','3|30','2','500','','','.*',0,0,0,0,0,4,1,0,0,0,0,0,'',''),(5,'phpbb_icq','profilefields.type.string','phpbb_icq','20','3','15','','','[0-9]+',0,0,0,0,0,6,1,1,0,1,1,1,'SEND_ICQ_MESSAGE','https://www.icq.com/people/%s/'),(6,'phpbb_yahoo','profilefields.type.string','phpbb_yahoo','40','5','255','','','.*',0,0,0,0,0,8,1,1,0,1,1,1,'SEND_YIM_MESSAGE','ymsgr:sendim?%s'),(7,'phpbb_facebook','profilefields.type.string','phpbb_facebook','20','5','50','','','[\\w.]+',0,0,0,0,1,9,1,1,0,1,1,1,'VIEW_FACEBOOK_PROFILE','https://facebook.com/%s/'),(8,'phpbb_twitter','profilefields.type.string','phpbb_twitter','20','1','15','','','[\\w_]+',0,0,0,0,1,10,1,1,0,1,1,1,'VIEW_TWITTER_PROFILE','https://twitter.com/%s'),(9,'phpbb_skype','profilefields.type.string','phpbb_skype','20','6','32','','','[a-zA-Z][\\w\\.,\\-_]+',0,0,0,0,1,11,1,1,0,1,1,1,'VIEW_SKYPE_PROFILE','skype:%s?userinfo'),(10,'phpbb_youtube','profilefields.type.string','phpbb_youtube','20','3','60','','','(@[a-zA-Z0-9_.-]{3,30}|c/[a-zA-Z][\\w\\.,\\-_]+|(channel|user)/[a-zA-Z][\\w\\.,\\-_]+)',0,0,0,0,1,12,1,1,0,1,1,1,'VIEW_YOUTUBE_PROFILE','https://youtube.com/%s');
/*!40000 ALTER TABLE `phpbb_profile_fields` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-09 16:48:59
